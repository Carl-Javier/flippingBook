BASE_URL = 'https://flippingbook.com/account/login'
LIST_PAGE = 'https://flippingbook.com/account/online'
USERNMAE = "mkt@bluebeeone.net"
PASSWORD = "BlueBeeOneIsNo1"