from scraper.driver_setup import Setup

inst = Setup()
inst.first_page()